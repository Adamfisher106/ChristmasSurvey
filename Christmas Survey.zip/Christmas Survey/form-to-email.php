<?php

if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $name = $_POST['name'];
  $starter = $_POST['starter'];   
  $main = $_POST['main'];
  $desert = $_POST['desert'];
  $drinks = $_POST['drinks'];
  $other = $_POST['other'];
  $trans = $_POST['trans'];

  $to = "$email";
  $subject = "Coming to Christmas Dinner";
  $message = "Order for Christmas Dinner:\n Name: ".$name." \n Starter: ".$starter." \n Main: ".$main." \n Desert: ".$desert." \n Drink: ".$drinks." ".$other."\n Transport: ".$trans." ";
  $header = 'From: christmaself@email.com' . "\r\n" . 'X-Mailer: PHP/' . phpversion();
  mail($to, $subject, $message, $header);
  header('Location: thank-you.html');
}

$file = "c:/meal/GoingToChristmasDinner.csv";
$write = "".$name.", ".$starter.", ".$main.", ".$desert.", ".$drinks.", ".$other.", ".$trans." \r\n ";
file_put_contents($file, $write, FILE_APPEND)

?>