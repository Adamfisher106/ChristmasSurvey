<!DOCTYPE HTML> 
<html>
<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>ITS XMAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
		<link rel="stylesheet" href="css/lights.css">
        <link href="https://fonts.googleapis.com/css?family=Mountains+of+Christmas" rel="stylesheet">
<!-- a helper script for vaidating the form-->
<script language="JavaScript" src="scripts/gen_validatorv31.js" type="text/javascript"></script>
</head>
<script>
    function validateForm() {
        var name = document.forms["myemailform"]["name"].value;
        if(name == "") {
            alert("Name must be filled out");
            return false;
        }
        var email = document.forms["myemailform"]["txt"].value;
        if(email == ""){
            alert("Reasons must be filled out");
            return false;
        }
    }
</script>
<body>
<audio autoplay loop>
        <source src="audio/ChrisRea_DrivingHomeForChristmas.mp3" type="audio/mpeg"> 
        <source src="ChrisRea_DrivingHomeForChristmas.ogg" type="audio/ogg">
</audio>
		<ul class="lightrope">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
	</ul>
<div class="buffer"></div>	
<!-- Start code for the form-->
<div class="container2">
    <h2>sorry you're not coming</h2>
<form method="post" name="myemailform" action="form-to-email-not.php" onsubmit="return validateForm()">
	<p>
		<label for='name'>Enter Name </label><br><br>
		<input class="text-input" type="text" name="name" maxlength="25">
    </p>
    <hr>
    <p>
        <label for="txt">Reason you're not coming:</label><br><br>
        <textarea name="txt" id="txt" cols="30" rows="10"></textarea>
    </p>
    <hr>
    <input class="btn btn-submit" type="submit" name='submit' value="Submit">
</form>
</div>
</body>
</html>