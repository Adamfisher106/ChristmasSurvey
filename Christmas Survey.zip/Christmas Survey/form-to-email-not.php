<?php
if(isset($_POST['submit']))
{
  $name = $_POST['name'];
  $txt = $_POST['txt'];
    $to = "ImAGrinch@email.com";
  $subject = "Not going to christmas Dinner";
  $message = "This Person is not coming to the Christmas Dinner: ".$name." \n  ".$txt." \r\n";  
  $header = 'From: christmaself@email.com' . "\r\n". 'X-Mailer: PHP/' . phpversion();
  mail($to, $subject, $message, $header);
  header('Location: thank-you.html');
}
$file = "c:/meal/notGoingToChristmasDinner.csv";
$write ="".$name.", ".$txt." \r\n ";
file_put_contents($file, $write, FILE_APPEND)
?>