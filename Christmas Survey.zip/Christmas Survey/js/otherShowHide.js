$(document).ready(function(){

    $("div#displayOtherDIV_Id").hide();

    $("input[name=drinks]").on("click",function(){
        var selectedValue = $("input[name=drinks]:cheecked").val();

        if(selectedValue == "other"){
            $("div#displayOtherDIV_Id").show();
        } else if(selectedValue == "whiteWine, redWine"){
            $("div#displayOtherDIV_Id").hide();
        }
    });
});