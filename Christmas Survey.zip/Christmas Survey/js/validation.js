function validateForm() {
    var name = document.forms["myemailform"]["name"].value;
    if(name == "") {
        alert("Name must be filled out");
        return false;
    }
    var email = document.forms["myemailform"]["email"].value;
    if(email == ""){
        alert("Email must be filled out");
        return false;
    }
}
function ValidateForm(form){

    ErrorText= "";

    if ( ( form.starter[0].checked == false ) && ( form.starter[1].checked == false ) && ( form.starter[2].checked == false ) && ( form.starter[3].checked == false ) && ( form.starter[4].checked == false )) 
        {
            alert ( "Please choose a Starter" ); 
            return false;
        }

    if ( ( form.main[0].checked == false ) && ( form.main[1].checked == false ) && ( form.main[2].checked == false ) && ( form.main[3].checked == false )) 
        {
            alert ( "Please choose a main" ); 
            return false;
        }

    if ( ( form.desert[0].checked == false ) && ( form.desert[1].checked == false ) && ( form.desert[2].checked == false ) && ( form.desert[3].checked == false ) && ( form.desert[4].checked == false )) 
        {
            alert ( "Please choose a dessert" ); 
            return false;
        }

    if ( ( form.drinks[0].checked == false ) && ( form.drinks[1].checked == false ) && ( form.drinks[2].checked == false )) 
        {
            alert ( "Please choose a Drink" ); 
            return false;
        }

    if ( ( form.trans[0].checked == false ) && ( form.trans[1].checked == false ) && ( form.trans[2].checked == false ) && ( form.trans[3].checked == false ) && ( form.trans[4].checked == false ) && ( form.trans[5].checked == false )) 
        {
            alert ( "Please choose a mode of transort" ); 
            return false;
        }

    if (ErrorText= "") 
        { 
            form.submit() 
        }

}