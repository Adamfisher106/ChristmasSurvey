<!DOCTYPE HTML> 
<html>
<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>ITS XMAS</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/style.css"/>
		<link rel="stylesheet" href="css/lights.css"/>
        <link rel="stylesheet" href="css/santa.css"/>
        <link rel="stylesheet" href="css/animate.min.css"/>
        <link href="https://fonts.googleapis.com/css?family=Mountains+of+Christmas" rel="stylesheet">
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.js"></script>
        <script src="js/validation.js"></script>
</head>
<body>
<audio autoplay loop>
        <source src="audio/VinceGuaraldiTrio-ChristmasTimeIsHere.mp3" type="audio/mpeg"> 
        <source src="audio/VinceGuaraldiTrio-ChristmasTimeIsHere.ogg" type="audio/ogg">
</audio>
<ul class="lightrope">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
</ul>
<div class="buffer"></div>	
<div class="container2">
<form method="post" name="myemailform" action="form-to-email.php" onsubmit="return validateForm()">
    <p>
		<label for='name'>Enter Name:</label><input class="text-input" type="text" name="name" placeholder="My name is Santa HO HO HO" maxlength="25" value="">          
        <br><br>
    </p>
   
	<p class="starter">
            <label class="title" for='starter'>Starter</label><br><br>      
            <input type="radio" id="Roasted_Butternut_Squash_Red_Pepper_Soup_with_basil_oil_V" name="starter" <?php if (isset($starter) && $starter=="Roasted Butternut Squash Red Pepper Soup with basil oil V") echo "checked";?> value="Roasted Butternut Squash Red Pepper Soup with basil oil V">
            <label for="Roasted_Butternut_Squash_Red_Pepper_Soup_with_basil_oil_V">Roasted Butternut Squash and Red Pepper Soup with basil oil (v)</label>
            <br> <!--help jeff sexually abuses every forest animals. he just won't--><br>
            <input type="radio" id="Duck_Liver_Port_Pate_tomato_chutney_melba_toasted_bread" name="starter" <?php if (isset($starter) && $starter=="Duck Liver Port Pate tomato chutney melba toasted bread") echo "checked";?> value="Duck Liver Port Pate tomato chutney melba toasted bread">
            <label for="Duck_Liver_Port_Pate_tomato_chutney_melba_toasted_bread">Duck Liver and Port Pate tomato chutney and melba toasted bread </label>
            <br><br>
            <input type="radio" name="starter" id="Prawn_Crayfish_Salad_sweet_dill_mayonnaise _gf" <?php if (isset($starter) && $starter=="Prawn Crayfish Salad sweet dill mayonnaise GF") echo "checked";?> value="Prawn Crayfish Salad sweet dill mayonnaise gf">
            <label for="Prawn_Crayfish_Salad_sweet_dill_mayonnaise _gf">Prawn and Crayfish Salad, sweet dill mayonnaise (gf)</label>
            <br><br>
            <input type="radio" name="starter" id="Breaded_Baby_Camembert_cranberry_compoteV" <?php if(isset($starter) && $starter=="Breaded Baby Camembert cranberry compote V") echo "checked"; ?> value="Breaded Baby Camembert cranberry compote V">
            <label for="Breaded_Baby_Camembert_cranberry_compoteV">Breaded Baby Camembert, cranberry compote(v)</label>
            <br><br>
            <input type="radio" name="starter" id="No_choice" <?php if(isset($starter) && $starter=="No choice") echo "checked";?> value="No choice">
            <label for="No_choice">I don't want a starter</label>
    </p>
	<p class="wow slideInUp">
        <label class="title" for='main'>Main</label><br><br>
        <input type="radio" name="main" id="Traditional_Roasted_Breast_of_Turkey_apricot_sage_stuffing_pigs_in_blanket" <?php if (isset($main) && $main=="Traditional Roasted Breast of Turkey apricot sage stuffing pigs in blanket") echo "checked";?> value="Traditional Roasted Breast of Turkey apricot sage stuffing pigs in blanket">
		<label for="Traditional_Roasted_Breast_of_Turkey_apricot_sage_stuffing_pigs_in_blanket">Traditional Roasted Breast of Turkey, apricot sage stuffing and pigs in blankets</label>
        <br><br>
        <input type="radio" name="main" id="Roasted_Fillet_of_Pork_cider_apple_sauce" <?php if (isset($main) && $main=="Roasted Fillet of Pork cider apple sauce") echo "checked";?> value="Roasted Fillet of Pork cider apple sauce">
		<label for="Roasted_Fillet_of_Pork_cider_apple_sauce">Roasted Fillet of Pork,  cider apple sauce</label>
        <br><br>
        <input type="radio" name="main" id="Oven_Baked_Salmon_Fillet_hollandaise_sauce" <?php if (isset($main) && $main=="Oven Baked Salmon Fillet hollandaise sauce") echo "checked";?> value="Oven Baked Salmon Fillet hollandaise sauce">
		<label for="Oven_Baked_Salmon_Fillet_hollandaise_sauce">Oven Baked Salmon Fillet, hollandaise sauce</label>
        <br><br>
        <input type="radio" name="main" id="Luxury_Nut_Roast_cashews_cranberry_V" <?php if (isset($main) && $main=="Luxury Nut Roast cashews cranberry V") echo "checked";?> value="Luxury Nut Roast cashews cranberry V">
        <label for="Luxury_Nut_Roast_cashews_cranberry_V">Luxury Nut Roast, cashews and cranberry (v)</label>
            <!--poor bambi-->
    </p>
	<p class="wow slideInUp">
		<label class="title" for="desert">Dessert</label><br><br>
       <br><br>
        <input type="radio" name="desert" id="Traditional_Christmas_Pudding_winter_berry_compote_brandy_sauce_V" <?php if (isset($desert) && $desert=="Traditional Christmas Pudding winter berry compote brandy sauce V") echo "checked";?> value="Traditional Christmas Pudding winter berry compote brandy sauce V">
        <label for="Traditional_Christmas_Pudding_winter_berry_compote_brandy_sauce_V">Traditional Christmas Pudding, winter berry compote and brandy sauce (v)</label>
       <br><br>
		<input type="radio" name="desert" id="Dark_Chocolate_Torte_GF_raspberry_coulis_clotted_cream" <?php if (isset($desert) && $desert=="Dark Chocolate Torte GF raspberry coulis clotted cream") echo "checked";?> value="Dark Chocolate Torte GF raspberry coulis clotted cream">
        <label for="Dark_Chocolate_Torte_GF_raspberry_coulis_clotted_cream">Dark Chocolate Torte (gf) raspberry coulis and clotted cream</label>
       <br><br>
        <input type="radio" name="desert" id="Baked_Vanilla_Cheesecake_caramel_sauce" <?php if (isset($desert) && $desert=="Baked Vanilla Cheesecake caramel sauce") echo "checked;"?> value="Baked Vanilla Cheesecake caramel sauce">
        <label for="Baked_Vanilla_Cheesecake_caramel_sauce">Baked Vanilla Cheesecake, caramel sauce</label>
       <br><br>
        <input type="radio" name="desert" id="Cheese_Biscuits_celery_grapes_caramelised_onion_chutney" <?php if(isset($desert) && $desert=="Cheese Biscuits celery grapes caramelised onion chutney") echo "checked";?> value="Cheese Biscuits celery grapes caramelised onion chutney">
        <label for="Cheese_Biscuits_celery_grapes_caramelised_onion_chutney">Cheese and Biscuits, celery, grapes and caramelised onion chutney </label>
       <br><br>
        <input type="radio" name="desert" id="No_choice_des" <?php if(isset($desert) && $desert=="No-choice") echo "checked";?> value="No choice Des">
        <label for="No_choice_des">I don't want a dessert</label>
    </p>
    <p class="wow slideInUp">
        <label class="title" for="drinks">Drinks</label>
        <br><br>
        <input onclick="document.getElementById('other-explain').value = ''" type="radio" name="drinks" id="redWine" <?php if(isset($drink) && $drink=="Red Wine") echo "checked";?> value="Red Wine">
        <label for="redWine">Red Wine</label>
       <br><br>
        <input onclick="document.getElementById('other-explain').value = ''" type="radio" name="drinks" id="whiteWine" <?php if(isset($drink) && $drink=="White Wine") echo "checked"; ?> value="White Wine">
        <label for="whiteWine">White Wine</label>
       <br><br>
    </p>
    <input class="bottom-input" id="other" name="drinks" type="radio" <?php if(isset($drink) && $drink=="Other -") echo "checked"; ?> value="Other -">
    <label for="other" class="side-label">Other</label>
    <div class="other-disclosure" style="padding-top:15px;">
        <label for="other-explain" class="top-label">Your Choice</label>
        <input class="text-input" id="other-explain" type="text" name="other" maxlength="50">
    </div><!--you think he'd stop near christmas-->
    <p>
    <label class="title" for="trans">Do you require a lift in Santa’s sleigh to the Party</label><br><br>
       <br><br>
        <input type="radio" name="trans" id="bexleyheath" <?php if (isset($trans) && $trans=="Bexleyheath") echo "checked";?> value="bexleyheath">
        <label for="bexleyheath">From Bexleyheath</label>
        <br><br>
        <input type="radio" name="trans" id="Dartford" <?php if (isset($trans) && $trans=="Dartford") echo "checked";?> value="Dartford">
        <label for="Dartford">From Dartford</label>
        <br><br>
        <input type="radio" name="trans" id="Welling" <?php if (isset($trans) && $trans=="Welling") echo "checked";?> value="Welling">
        <label for="Welling">From Welling</label>
        <br><br>
        <input type="radio" name="trans" id="Sidcup" <?php if (isset($trans) && $trans=="Sidcup") echo "checked";?> value="Sidcup">
        <label for="Sidcup">From Sidcup</label>
        <br><br>
        <input type="radio" name="trans" id="Orpington" <?php if (isset($trans) && $trans=="Orpington") echo "checked";?> value="Orpington">
        <label for="Orpington">From Orpington</label>
        <br><br>
        <input type="radio" name="trans" id="No" <?php if (isset($trans) && $trans=="No") echo "checked";?> value="No">
        <label for="No">I have my own reindeer, thank you.</label>
    </p>
    <p>
    <label class="title">Add your Email so you can remember what you ordered</label><br><br>
        <label for="email">Enter your Email Address: </label>
        <input class="text-input" type="text" name="email" placeholder="elf@santasgrotto.com" maxlength="50">
    </p>
    <div style="width:100%;">
	    <button class="btn btn-submit" type="submit" name='submit'  onClick="ValidateForm(this.form)">Send Order</button>
    </div>
</form>
<!--he needs to stop using the ketchup-->
</div>
<div class="window">
    <div class="santa">
        <div class="head">
            <div class="face">
                <div class="redhat">
                    <div class="whitepart"></div>
                    <div class="redpart"></div>
                    <div class="hatball"></div>
                </div>
                <div class="eyes"></div>
                <div class="beard">
                    <div class="nouse"></div>
                    <div class="mouth"></div>	
				</div>
            </div>
            <div class="ears"></div>
        </div>
        <div class="body"></div>
    </div>
</div>
<div class="window_2">
    <snowman>
	    <div class="body">
		    <div class="head"></div>
    		<div class="hat"></div>
	    	<div class="scarf"></div>
            <div class="buttons"></div>
    		<div class="hands">
	    		<div class="right-hand"></div>
		    	<div class="left-hand"></div>
    		</div>
	    	<div class="shadow"></div>
	    </div>
    </snowman>
</div>
</body>
</html>
